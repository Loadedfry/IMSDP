from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add/', views.add_course, name='add_course'),
    path('course/<str:course_id>/', views.course_detail, name='course_detail'),
    path('search/', views.search_course, name='search_course'),
    path('update/<str:course_id>/', views.update_course, name='update_course'),
    path('delete/<str:course_id>/', views.delete_course, name='delete_course'),
    path('compulsory/', views.compulsory_courses, name='compulsory_courses'),
    path('elective/', views.elective_courses, name='elective_courses'),  # Add this line
]
