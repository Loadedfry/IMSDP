from django.shortcuts import render, get_object_or_404, redirect
from .models import Course

#Home view that display all courses
def home(request):
    courses = Course.objects.all()
    return render(request, 'courses/home.html', {'courses': courses})

#View to add a new course
def add_course(request):
    if request.method == 'POST':
        course_id = request.POST['course_id']
        name = request.POST['name']
        credit = request.POST['credit']
        class_hour = request.POST['class_hour']
        course_type = request.POST['course_type']
        teacher = request.POST['teacher']
        Course.objects.create(course_id=course_id, name=name, credit=credit, class_hour=class_hour, course_type=course_type, teacher=teacher)
        return redirect('home')
    return render(request, 'courses/add_course.html')

def course_detail(request, course_id):
    course = get_object_or_404(Course, course_id=course_id)
    return render(request, 'courses/course_detail.html', {'course': course})

def search_course(request):
    query = request.GET.get('q')
    results = Course.objects.filter(course_id__icontains=query) | Course.objects.filter(name__icontains=query)
    return render(request, 'courses/search_results.html', {'results': results})

def update_course(request, course_id):
    course = get_object_or_404(Course, course_id=course_id)
    if request.method == 'POST':
        course.name = request.POST['name']
        course.credit = request.POST['credit']
        course.class_hour = request.POST['class_hour']
        course.course_type = request.POST['course_type']
        course.teacher = request.POST['teacher']
        course.save()
        return redirect('home')
    return render(request, 'courses/update_course.html', {'course': course})

def delete_course(request, course_id):
    course = get_object_or_404(Course, course_id=course_id)
    if request.method == 'POST':
        course.delete()
        return redirect('home')
    return render(request, 'courses/delete_course.html', {'course': course})

def compulsory_courses(request):
    courses = Course.objects.filter(course_type='compulsory')
    return render(request, 'courses/compulsory_courses.html', {'courses': courses})

def search_course(request):
    query = request.GET.get('q')
    results = Course.objects.filter(course_id__icontains=query) | Course.objects.filter(name__icontains=query)
    return render(request, 'courses/search_results.html', {'results': results})


def elective_courses(request):
    courses = Course.objects.filter(course_type='elective')
    return render(request, 'courses/elective_courses.html', {'courses': courses})

