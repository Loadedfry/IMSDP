from django.db import models

class Course(models.Model):
    course_id = models.CharField(max_length=10, primary_key=True)
    name = models.CharField(max_length=100)
    credit = models.IntegerField()
    class_hour = models.IntegerField()
    course_type = models.CharField(max_length=50, choices=[('compulsory', 'Compulsory'), ('elective', 'Elective')])
    teacher = models.CharField(max_length=100)

    def __str__(self):
        return self.name
